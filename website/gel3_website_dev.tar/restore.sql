--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 12.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE gel3_website_dev;
--
-- Name: gel3_website_dev; Type: DATABASE; Schema: -; Owner: m044451
--

CREATE DATABASE gel3_website_dev WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'C' LC_CTYPE = 'C';


ALTER DATABASE gel3_website_dev OWNER TO m044451;

\connect gel3_website_dev

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Image; Type: TABLE; Schema: public; Owner: m044451
--

CREATE TABLE public."Image" (
    id integer NOT NULL,
    image jsonb,
    caption text
);


ALTER TABLE public."Image" OWNER TO m044451;

--
-- Name: Image_id_seq; Type: SEQUENCE; Schema: public; Owner: m044451
--

CREATE SEQUENCE public."Image_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Image_id_seq" OWNER TO m044451;

--
-- Name: Image_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: m044451
--

ALTER SEQUENCE public."Image_id_seq" OWNED BY public."Image".id;


--
-- Name: Page; Type: TABLE; Schema: public; Owner: m044451
--

CREATE TABLE public."Page" (
    id integer NOT NULL,
    "pageTitle" text,
    "packageName" text,
    "hideAccessibilityTab" boolean,
    "hideCodeTab" boolean,
    url text,
    CONSTRAINT "Page_packageName_check" CHECK (("packageName" = ANY (ARRAY['a11y'::text, 'alert'::text, 'badge'::text, 'body'::text, 'breadcrumb'::text, 'button'::text, 'button_dropdown'::text, 'button_group'::text, 'core'::text, 'form'::text, 'form_check'::text, 'form_pod'::text, 'grid'::text, 'heading'::text, 'hooks'::text, 'icon'::text, 'input_group'::text, 'label'::text, 'list'::text, 'list_group'::text, 'modal'::text, 'pagination'::text, 'panel'::text, 'popover'::text, 'progress_bar'::text, 'progress_rope'::text, 'switch'::text, 'symbol'::text, 'tabcordion'::text, 'table'::text, 'text_input'::text, 'well'::text])))
);


ALTER TABLE public."Page" OWNER TO m044451;

--
-- Name: Page_id_seq; Type: SEQUENCE; Schema: public; Owner: m044451
--

CREATE SEQUENCE public."Page_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Page_id_seq" OWNER TO m044451;

--
-- Name: Page_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: m044451
--

ALTER SEQUENCE public."Page_id_seq" OWNED BY public."Page".id;


--
-- Name: Page_relatedPages_many; Type: TABLE; Schema: public; Owner: m044451
--

CREATE TABLE public."Page_relatedPages_many" (
    "Page_left_id" integer NOT NULL,
    "Page_right_id" integer NOT NULL
);


ALTER TABLE public."Page_relatedPages_many" OWNER TO m044451;

--
-- Name: Setting; Type: TABLE; Schema: public; Owner: m044451
--

CREATE TABLE public."Setting" (
    id integer NOT NULL,
    name text,
    value text
);


ALTER TABLE public."Setting" OWNER TO m044451;

--
-- Name: Setting_id_seq; Type: SEQUENCE; Schema: public; Owner: m044451
--

CREATE SEQUENCE public."Setting_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Setting_id_seq" OWNER TO m044451;

--
-- Name: Setting_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: m044451
--

ALTER SEQUENCE public."Setting_id_seq" OWNED BY public."Setting".id;


--
-- Name: User; Type: TABLE; Schema: public; Owner: m044451
--

CREATE TABLE public."User" (
    id integer NOT NULL,
    email text,
    password character varying(60)
);


ALTER TABLE public."User" OWNER TO m044451;

--
-- Name: User_id_seq; Type: SEQUENCE; Schema: public; Owner: m044451
--

CREATE SEQUENCE public."User_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."User_id_seq" OWNER TO m044451;

--
-- Name: User_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: m044451
--

ALTER SEQUENCE public."User_id_seq" OWNED BY public."User".id;


--
-- Name: _ContentType_Page_accessibility; Type: TABLE; Schema: public; Owner: m044451
--

CREATE TABLE public."_ContentType_Page_accessibility" (
    id integer NOT NULL,
    document text,
    "from" integer
);


ALTER TABLE public."_ContentType_Page_accessibility" OWNER TO m044451;

--
-- Name: _ContentType_Page_accessibility_id_seq; Type: SEQUENCE; Schema: public; Owner: m044451
--

CREATE SEQUENCE public."_ContentType_Page_accessibility_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."_ContentType_Page_accessibility_id_seq" OWNER TO m044451;

--
-- Name: _ContentType_Page_accessibility_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: m044451
--

ALTER SEQUENCE public."_ContentType_Page_accessibility_id_seq" OWNED BY public."_ContentType_Page_accessibility".id;


--
-- Name: _ContentType_Page_code; Type: TABLE; Schema: public; Owner: m044451
--

CREATE TABLE public."_ContentType_Page_code" (
    id integer NOT NULL,
    document text,
    "from" integer
);


ALTER TABLE public."_ContentType_Page_code" OWNER TO m044451;

--
-- Name: _ContentType_Page_code_id_seq; Type: SEQUENCE; Schema: public; Owner: m044451
--

CREATE SEQUENCE public."_ContentType_Page_code_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."_ContentType_Page_code_id_seq" OWNER TO m044451;

--
-- Name: _ContentType_Page_code_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: m044451
--

ALTER SEQUENCE public."_ContentType_Page_code_id_seq" OWNED BY public."_ContentType_Page_code".id;


--
-- Name: _ContentType_Page_design; Type: TABLE; Schema: public; Owner: m044451
--

CREATE TABLE public."_ContentType_Page_design" (
    id integer NOT NULL,
    document text,
    "from" integer
);


ALTER TABLE public."_ContentType_Page_design" OWNER TO m044451;

--
-- Name: _ContentType_Page_design_id_seq; Type: SEQUENCE; Schema: public; Owner: m044451
--

CREATE SEQUENCE public."_ContentType_Page_design_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."_ContentType_Page_design_id_seq" OWNER TO m044451;

--
-- Name: _ContentType_Page_design_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: m044451
--

ALTER SEQUENCE public."_ContentType_Page_design_id_seq" OWNED BY public."_ContentType_Page_design".id;


--
-- Name: _ContentType_Page_relatedInfo; Type: TABLE; Schema: public; Owner: m044451
--

CREATE TABLE public."_ContentType_Page_relatedInfo" (
    id integer NOT NULL,
    document text,
    "from" integer
);


ALTER TABLE public."_ContentType_Page_relatedInfo" OWNER TO m044451;

--
-- Name: _ContentType_Page_relatedInfo_id_seq; Type: SEQUENCE; Schema: public; Owner: m044451
--

CREATE SEQUENCE public."_ContentType_Page_relatedInfo_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."_ContentType_Page_relatedInfo_id_seq" OWNER TO m044451;

--
-- Name: _ContentType_Page_relatedInfo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: m044451
--

ALTER SEQUENCE public."_ContentType_Page_relatedInfo_id_seq" OWNED BY public."_ContentType_Page_relatedInfo".id;


--
-- Name: knex_migrations; Type: TABLE; Schema: public; Owner: m044451
--

CREATE TABLE public.knex_migrations (
    id integer NOT NULL,
    name character varying(255),
    batch integer,
    migration_time timestamp with time zone
);


ALTER TABLE public.knex_migrations OWNER TO m044451;

--
-- Name: knex_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: m044451
--

CREATE SEQUENCE public.knex_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.knex_migrations_id_seq OWNER TO m044451;

--
-- Name: knex_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: m044451
--

ALTER SEQUENCE public.knex_migrations_id_seq OWNED BY public.knex_migrations.id;


--
-- Name: knex_migrations_lock; Type: TABLE; Schema: public; Owner: m044451
--

CREATE TABLE public.knex_migrations_lock (
    index integer NOT NULL,
    is_locked integer
);


ALTER TABLE public.knex_migrations_lock OWNER TO m044451;

--
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE; Schema: public; Owner: m044451
--

CREATE SEQUENCE public.knex_migrations_lock_index_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.knex_migrations_lock_index_seq OWNER TO m044451;

--
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: m044451
--

ALTER SEQUENCE public.knex_migrations_lock_index_seq OWNED BY public.knex_migrations_lock.index;


--
-- Name: Image id; Type: DEFAULT; Schema: public; Owner: m044451
--

ALTER TABLE ONLY public."Image" ALTER COLUMN id SET DEFAULT nextval('public."Image_id_seq"'::regclass);


--
-- Name: Page id; Type: DEFAULT; Schema: public; Owner: m044451
--

ALTER TABLE ONLY public."Page" ALTER COLUMN id SET DEFAULT nextval('public."Page_id_seq"'::regclass);


--
-- Name: Setting id; Type: DEFAULT; Schema: public; Owner: m044451
--

ALTER TABLE ONLY public."Setting" ALTER COLUMN id SET DEFAULT nextval('public."Setting_id_seq"'::regclass);


--
-- Name: User id; Type: DEFAULT; Schema: public; Owner: m044451
--

ALTER TABLE ONLY public."User" ALTER COLUMN id SET DEFAULT nextval('public."User_id_seq"'::regclass);


--
-- Name: _ContentType_Page_accessibility id; Type: DEFAULT; Schema: public; Owner: m044451
--

ALTER TABLE ONLY public."_ContentType_Page_accessibility" ALTER COLUMN id SET DEFAULT nextval('public."_ContentType_Page_accessibility_id_seq"'::regclass);


--
-- Name: _ContentType_Page_code id; Type: DEFAULT; Schema: public; Owner: m044451
--

ALTER TABLE ONLY public."_ContentType_Page_code" ALTER COLUMN id SET DEFAULT nextval('public."_ContentType_Page_code_id_seq"'::regclass);


--
-- Name: _ContentType_Page_design id; Type: DEFAULT; Schema: public; Owner: m044451
--

ALTER TABLE ONLY public."_ContentType_Page_design" ALTER COLUMN id SET DEFAULT nextval('public."_ContentType_Page_design_id_seq"'::regclass);


--
-- Name: _ContentType_Page_relatedInfo id; Type: DEFAULT; Schema: public; Owner: m044451
--

ALTER TABLE ONLY public."_ContentType_Page_relatedInfo" ALTER COLUMN id SET DEFAULT nextval('public."_ContentType_Page_relatedInfo_id_seq"'::regclass);


--
-- Name: knex_migrations id; Type: DEFAULT; Schema: public; Owner: m044451
--

ALTER TABLE ONLY public.knex_migrations ALTER COLUMN id SET DEFAULT nextval('public.knex_migrations_id_seq'::regclass);


--
-- Name: knex_migrations_lock index; Type: DEFAULT; Schema: public; Owner: m044451
--

ALTER TABLE ONLY public.knex_migrations_lock ALTER COLUMN index SET DEFAULT nextval('public.knex_migrations_lock_index_seq'::regclass);


--
-- Data for Name: Image; Type: TABLE DATA; Schema: public; Owner: m044451
--

COPY public."Image" (id, image, caption) FROM stdin;
\.
COPY public."Image" (id, image, caption) FROM '$$PATH$$/3299.dat';

--
-- Data for Name: Page; Type: TABLE DATA; Schema: public; Owner: m044451
--

COPY public."Page" (id, "pageTitle", "packageName", "hideAccessibilityTab", "hideCodeTab", url) FROM stdin;
\.
COPY public."Page" (id, "pageTitle", "packageName", "hideAccessibilityTab", "hideCodeTab", url) FROM '$$PATH$$/3301.dat';

--
-- Data for Name: Page_relatedPages_many; Type: TABLE DATA; Schema: public; Owner: m044451
--

COPY public."Page_relatedPages_many" ("Page_left_id", "Page_right_id") FROM stdin;
\.
COPY public."Page_relatedPages_many" ("Page_left_id", "Page_right_id") FROM '$$PATH$$/3315.dat';

--
-- Data for Name: Setting; Type: TABLE DATA; Schema: public; Owner: m044451
--

COPY public."Setting" (id, name, value) FROM stdin;
\.
COPY public."Setting" (id, name, value) FROM '$$PATH$$/3303.dat';

--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: m044451
--

COPY public."User" (id, email, password) FROM stdin;
\.
COPY public."User" (id, email, password) FROM '$$PATH$$/3305.dat';

--
-- Data for Name: _ContentType_Page_accessibility; Type: TABLE DATA; Schema: public; Owner: m044451
--

COPY public."_ContentType_Page_accessibility" (id, document, "from") FROM stdin;
\.
COPY public."_ContentType_Page_accessibility" (id, document, "from") FROM '$$PATH$$/3307.dat';

--
-- Data for Name: _ContentType_Page_code; Type: TABLE DATA; Schema: public; Owner: m044451
--

COPY public."_ContentType_Page_code" (id, document, "from") FROM stdin;
\.
COPY public."_ContentType_Page_code" (id, document, "from") FROM '$$PATH$$/3309.dat';

--
-- Data for Name: _ContentType_Page_design; Type: TABLE DATA; Schema: public; Owner: m044451
--

COPY public."_ContentType_Page_design" (id, document, "from") FROM stdin;
\.
COPY public."_ContentType_Page_design" (id, document, "from") FROM '$$PATH$$/3311.dat';

--
-- Data for Name: _ContentType_Page_relatedInfo; Type: TABLE DATA; Schema: public; Owner: m044451
--

COPY public."_ContentType_Page_relatedInfo" (id, document, "from") FROM stdin;
\.
COPY public."_ContentType_Page_relatedInfo" (id, document, "from") FROM '$$PATH$$/3313.dat';

--
-- Data for Name: knex_migrations; Type: TABLE DATA; Schema: public; Owner: m044451
--

COPY public.knex_migrations (id, name, batch, migration_time) FROM stdin;
\.
COPY public.knex_migrations (id, name, batch, migration_time) FROM '$$PATH$$/3296.dat';

--
-- Data for Name: knex_migrations_lock; Type: TABLE DATA; Schema: public; Owner: m044451
--

COPY public.knex_migrations_lock (index, is_locked) FROM stdin;
\.
COPY public.knex_migrations_lock (index, is_locked) FROM '$$PATH$$/3298.dat';

--
-- Name: Image_id_seq; Type: SEQUENCE SET; Schema: public; Owner: m044451
--

SELECT pg_catalog.setval('public."Image_id_seq"', 1, false);


--
-- Name: Page_id_seq; Type: SEQUENCE SET; Schema: public; Owner: m044451
--

SELECT pg_catalog.setval('public."Page_id_seq"', 2, true);


--
-- Name: Setting_id_seq; Type: SEQUENCE SET; Schema: public; Owner: m044451
--

SELECT pg_catalog.setval('public."Setting_id_seq"', 1, true);


--
-- Name: User_id_seq; Type: SEQUENCE SET; Schema: public; Owner: m044451
--

SELECT pg_catalog.setval('public."User_id_seq"', 1, true);


--
-- Name: _ContentType_Page_accessibility_id_seq; Type: SEQUENCE SET; Schema: public; Owner: m044451
--

SELECT pg_catalog.setval('public."_ContentType_Page_accessibility_id_seq"', 1, true);


--
-- Name: _ContentType_Page_code_id_seq; Type: SEQUENCE SET; Schema: public; Owner: m044451
--

SELECT pg_catalog.setval('public."_ContentType_Page_code_id_seq"', 1, true);


--
-- Name: _ContentType_Page_design_id_seq; Type: SEQUENCE SET; Schema: public; Owner: m044451
--

SELECT pg_catalog.setval('public."_ContentType_Page_design_id_seq"', 8, true);


--
-- Name: _ContentType_Page_relatedInfo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: m044451
--

SELECT pg_catalog.setval('public."_ContentType_Page_relatedInfo_id_seq"', 1, false);


--
-- Name: knex_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: m044451
--

SELECT pg_catalog.setval('public.knex_migrations_id_seq', 4, true);


--
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE SET; Schema: public; Owner: m044451
--

SELECT pg_catalog.setval('public.knex_migrations_lock_index_seq', 1, true);


--
-- Name: Image Image_pkey; Type: CONSTRAINT; Schema: public; Owner: m044451
--

ALTER TABLE ONLY public."Image"
    ADD CONSTRAINT "Image_pkey" PRIMARY KEY (id);


--
-- Name: Page Page_pkey; Type: CONSTRAINT; Schema: public; Owner: m044451
--

ALTER TABLE ONLY public."Page"
    ADD CONSTRAINT "Page_pkey" PRIMARY KEY (id);


--
-- Name: Setting Setting_pkey; Type: CONSTRAINT; Schema: public; Owner: m044451
--

ALTER TABLE ONLY public."Setting"
    ADD CONSTRAINT "Setting_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: m044451
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _ContentType_Page_accessibility _ContentType_Page_accessibility_pkey; Type: CONSTRAINT; Schema: public; Owner: m044451
--

ALTER TABLE ONLY public."_ContentType_Page_accessibility"
    ADD CONSTRAINT "_ContentType_Page_accessibility_pkey" PRIMARY KEY (id);


--
-- Name: _ContentType_Page_code _ContentType_Page_code_pkey; Type: CONSTRAINT; Schema: public; Owner: m044451
--

ALTER TABLE ONLY public."_ContentType_Page_code"
    ADD CONSTRAINT "_ContentType_Page_code_pkey" PRIMARY KEY (id);


--
-- Name: _ContentType_Page_design _ContentType_Page_design_pkey; Type: CONSTRAINT; Schema: public; Owner: m044451
--

ALTER TABLE ONLY public."_ContentType_Page_design"
    ADD CONSTRAINT "_ContentType_Page_design_pkey" PRIMARY KEY (id);


--
-- Name: _ContentType_Page_relatedInfo _ContentType_Page_relatedInfo_pkey; Type: CONSTRAINT; Schema: public; Owner: m044451
--

ALTER TABLE ONLY public."_ContentType_Page_relatedInfo"
    ADD CONSTRAINT "_ContentType_Page_relatedInfo_pkey" PRIMARY KEY (id);


--
-- Name: knex_migrations_lock knex_migrations_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: m044451
--

ALTER TABLE ONLY public.knex_migrations_lock
    ADD CONSTRAINT knex_migrations_lock_pkey PRIMARY KEY (index);


--
-- Name: knex_migrations knex_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: m044451
--

ALTER TABLE ONLY public.knex_migrations
    ADD CONSTRAINT knex_migrations_pkey PRIMARY KEY (id);


--
-- Name: _contenttype_page_accessibility_from_index; Type: INDEX; Schema: public; Owner: m044451
--

CREATE INDEX _contenttype_page_accessibility_from_index ON public."_ContentType_Page_accessibility" USING btree ("from");


--
-- Name: _contenttype_page_code_from_index; Type: INDEX; Schema: public; Owner: m044451
--

CREATE INDEX _contenttype_page_code_from_index ON public."_ContentType_Page_code" USING btree ("from");


--
-- Name: _contenttype_page_design_from_index; Type: INDEX; Schema: public; Owner: m044451
--

CREATE INDEX _contenttype_page_design_from_index ON public."_ContentType_Page_design" USING btree ("from");


--
-- Name: _contenttype_page_relatedinfo_from_index; Type: INDEX; Schema: public; Owner: m044451
--

CREATE INDEX _contenttype_page_relatedinfo_from_index ON public."_ContentType_Page_relatedInfo" USING btree ("from");


--
-- Name: page_relatedpages_many_page_left_id_index; Type: INDEX; Schema: public; Owner: m044451
--

CREATE INDEX page_relatedpages_many_page_left_id_index ON public."Page_relatedPages_many" USING btree ("Page_left_id");


--
-- Name: page_relatedpages_many_page_right_id_index; Type: INDEX; Schema: public; Owner: m044451
--

CREATE INDEX page_relatedpages_many_page_right_id_index ON public."Page_relatedPages_many" USING btree ("Page_right_id");


--
-- Name: _ContentType_Page_accessibility _contenttype_page_accessibility_from_foreign; Type: FK CONSTRAINT; Schema: public; Owner: m044451
--

ALTER TABLE ONLY public."_ContentType_Page_accessibility"
    ADD CONSTRAINT _contenttype_page_accessibility_from_foreign FOREIGN KEY ("from") REFERENCES public."Page"(id);


--
-- Name: _ContentType_Page_code _contenttype_page_code_from_foreign; Type: FK CONSTRAINT; Schema: public; Owner: m044451
--

ALTER TABLE ONLY public."_ContentType_Page_code"
    ADD CONSTRAINT _contenttype_page_code_from_foreign FOREIGN KEY ("from") REFERENCES public."Page"(id);


--
-- Name: _ContentType_Page_design _contenttype_page_design_from_foreign; Type: FK CONSTRAINT; Schema: public; Owner: m044451
--

ALTER TABLE ONLY public."_ContentType_Page_design"
    ADD CONSTRAINT _contenttype_page_design_from_foreign FOREIGN KEY ("from") REFERENCES public."Page"(id);


--
-- Name: _ContentType_Page_relatedInfo _contenttype_page_relatedinfo_from_foreign; Type: FK CONSTRAINT; Schema: public; Owner: m044451
--

ALTER TABLE ONLY public."_ContentType_Page_relatedInfo"
    ADD CONSTRAINT _contenttype_page_relatedinfo_from_foreign FOREIGN KEY ("from") REFERENCES public."Page"(id);


--
-- Name: Page_relatedPages_many page_relatedpages_many_page_left_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: m044451
--

ALTER TABLE ONLY public."Page_relatedPages_many"
    ADD CONSTRAINT page_relatedpages_many_page_left_id_foreign FOREIGN KEY ("Page_left_id") REFERENCES public."Page"(id) ON DELETE CASCADE;


--
-- Name: Page_relatedPages_many page_relatedpages_many_page_right_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: m044451
--

ALTER TABLE ONLY public."Page_relatedPages_many"
    ADD CONSTRAINT page_relatedpages_many_page_right_id_foreign FOREIGN KEY ("Page_right_id") REFERENCES public."Page"(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

